package DesignQuestions.ShoppingCart;

public interface Invoice {

    void generateInvoice();
}
