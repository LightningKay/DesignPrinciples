package DesignQuestions.ShoppingCart;

public interface PromoCode {

    double getDiscount();
}
