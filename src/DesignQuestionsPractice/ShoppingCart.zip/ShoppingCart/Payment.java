package DesignQuestions.ShoppingCart;

public interface Payment {

    void processPayment();
}
