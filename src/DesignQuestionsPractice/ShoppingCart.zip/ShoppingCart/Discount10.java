package DesignQuestions.ShoppingCart;

public class Discount10 implements PromoCode{
    @Override
    public double getDiscount() {
        return 0.1;
    }
}
