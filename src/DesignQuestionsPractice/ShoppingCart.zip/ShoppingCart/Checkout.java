package DesignQuestions.ShoppingCart;

public interface Checkout {

    double calculateTotal();

}
