package DesignQuestions.ShoppingCart;

public class CartService {

    Cart cart;
    public CartService(Cart car){
        this.cart = cart;
    }
}
