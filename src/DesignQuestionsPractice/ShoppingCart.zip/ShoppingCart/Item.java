package DesignQuestions.ShoppingCart;

public class Item {
    long productId;
    double price;

    public Item(long productId, double price){
        this.productId = productId;
        this.price = price;
    }
}
