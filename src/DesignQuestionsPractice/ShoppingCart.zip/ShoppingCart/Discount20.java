package DesignQuestions.ShoppingCart;

public class Discount20 implements PromoCode{
    @Override
    public double getDiscount() {
        return 0.2;
    }
}
